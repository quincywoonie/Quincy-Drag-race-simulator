WERKROOM ROYALE - SPOTIFY & RUNWAY UPDATE

Files:
- index.html: complete standalone game.

Deploying to Netlify:
1. Extract this ZIP.
2. Upload the extracted folder (or index.html) to your Netlify site using Deploy manually.
3. Open the deployed site in Safari.

What's updated:
- Removed the final runway turn-over/rotation from the runway walk.
- Removed the nameplate beneath the queen's runway image.
- Made the episode recap action bar sticky so Next episode stays reachable.
- Replaced Apple Music/iTunes search with a curated 137-track starter vault focused on K-pop, pop, dance-pop and power ballads.
- Added Spotify search links for curated songs.
- Added a direct Spotify track-link importer. Paste a Spotify track URL and supply title/artist if needed; Spotify's public oEmbed endpoint may provide the official cover thumbnail.
- No audio files are bundled or played.

Important music-source note:
The static game does not call Spotify's authenticated Web API. Spotify's Web API requires app authorization and Development Mode has owner/account and user limits. This version avoids putting private API secrets in a public HTML file by using Spotify search links and the public oEmbed endpoint for direct track links. The starter vault contains 137 curated entries, not 1,000; you can expand it by importing more Spotify track links.
